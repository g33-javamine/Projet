<!DOCTYPE html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="forme.css">

<html>
<head>
	<title> Inscription bénévole </title>
</head>	

<style>
	#form{
		margin-left : 30%;
		margin-right: 30%;
		margin-top : 5%;
		margin-bottom: 5%;
		color : #104E17;
	}
	#separation{
		background-color : #104E17 ;
		height : 2px;
		margin-left : 5%;
		margin-right : 5%;
	}
</style>


<body>

	<h1 id="corps">
			<span>
				<img src="Images/logo.png" alt="mcu" id="logo">
				<span class="titre"> Inscription </span>
				<img src="Images/logo.png" alt="mcu" id="logo">
			</span>
	</h1>

	<img src="Images/spons1.png" alt="mcu" id="logos">

	<div id="tete"><br></div>

	<?php include 'navbar.php' ?>

	<h2 class="border border-dark">
		<div id="form">
		<form id="InscriptionB" action="ConfirmationB.php" method="post">
			<font size="+4">BOL D'AIR </font>
			<br> <br>
		
  		

  			<div class="form-group">
				<label id="nom" for="inputNom">  Nom   </label>
				<input type="text" id="inputNom" name="nom" class="form-control" placeholder="Entrez nom" required>
			</div>
			<br>

			<div class="form-group">
				<label id="prenom" for="inputPrenom">  Prénom  </label>
				<input type="text" id="inputPrenom" name="prenom" class="form-control" placeholder="Entrez prenom " required>
			</div>
			<br>

			<div class="form-group">
				<label id="naissance" for="inputNaissance"> Date de naissance  </label>
				<input type="text" id="inputNaissance" name="naissance" class="form-control" placeholder="Format AAAA-MM-JJ" required>
			</div>
			<br>

			<div class="form-group">
				<label id="tel" for="inputTel"> N° de téléphone </label>
				<input type="text" id="inputTel" name="tel" class="form-control" placeholder="Entrez n° de téléphone" required>
			</div>
			<br>
  		
  			<div class="form-group">
				<label id="mail" for="inputMail">  Adresse mail  </label>
				<input type="mail" id="inputMail" name="mail" class="form-control" placeholder="Entrez adresse mail" required>
			</div>
			<br>
		
			<div class="form-group">
				<label id="adresse" for="inputAdresse">  Adresse   </label>
				<input type="text" id="inputAdresse" name="adresse" class="form-control" placeholder="Entrez adresse adresse" required>
			</div>
			<br>
		
			<div class="form-group">
				<label id="login" for="inputLogin">  Login  </label>
				<input type="text" id="inputLogin" name="login" class="form-control" placeholder="Entrez adresse login" required>
			</div>
			<br>

			<div class="form-group">
				<label id="mdp" for="inputMdp">  Mot de passe  </label>
				<input type="password" id="inputMdp" name="mdp" class="form-control" placeholder="Entrez un mot de passe" required>
			</div>	
		</div>

		<div id="separation"></div>

  		<div id="form">
  			<font size="+4">PERMIS DE CONDUIRE </font>
  			<br>
  			<br>
  			<div class="form-group">
				<label id="NumeroPermis" for="inputNumeroPermis">  Numéro du permis  </label>
				<input type="text" id="inputNumeroPermis" name="numeroPermis" class="form-control" placeholder="Entrez numéro du permis" >
			</div>
			<br>

			<div class="form-group">
				<label id="datePermis" for="inputDatePermis"> Date de délivrance  </label>
				<input type="text" id="inputDatePermis" name="datePermis" class="form-control" placeholder="Format AAAA-MM-JJ">
			</div>

			<br>

			<div class="form-group">
				<label id="delivrance" for="inputDelivrance">  Lieu de délivrance (préfecture)  </label>
				<input type="text" id="inputDelivrance" name="delivrance" class="form-control" placeholder="Entrez lieu de délivrance (préfecture)">
			</div>
		</div>

		<button id="bouton" type="submit" class=" btn btn-outline-success">   Valider   </button>
  	</div>	
	</form>

	<br><br>

	<div id="form"> 
		<button type="submit" id="bouton" class=" btn btn-outline-success"> <strong> <a href="accueil.php"> Retour à l'accueil </a></strong> </button> 
	</div>
	</h2>

	<br>  

	<img src="Images/spons2.png" alt="mcu" id="logos">
	<img src="Images/spons3.png" alt="mcu" id="logos">
	<img src="Images/spons4.png" alt="mcu" id="logos">

</body>