<?php
	session_start();
	$BDD = new PDO('pgsql:host=localhost;port=5432;dbname=postgres','admin','adminadmin');

	$nom = $_POST["nom"];
	$prenom = $_POST["prenom"];
	$tel = $_POST["tel"];
	$mail = $_POST["mail"];
	$adresse = $_POST["adresse"];
	$date = $_POST["naissance"];
	$login = $_POST["login"];
	$mdp = $_POST["mdp"];

	$numero = $_POST["numeroPermis"];
	$datePermis = $_POST["datePermis"];
	$prefecture = $_POST["delivrance"];


	if(strlen($tel) != 10){

		header("Location: erreurTel.php");
		exit();
	}


	if(strlen($mdp) < 6){

		header("Location: erreurMdp.php");
		exit();
	}

	if(strlen($login) < 6){

		header("Location: erreurLogin.php");
		exit();
	}


	if(isset($numero)){
	        if(strlen($numero) != 9){
	        	header("Location: erreurPermis.php");
	        	exit();
					}
				}


	$texteRequete = "INSERT INTO projet.personne(nom,prenom,datenaissance,tel,mail,adresse) VALUES (:nom,:prenom,DATE '$date',:tel,:mail,:adresse)";
	$requete = $BDD ->prepare($texteRequete);
	$requete->bindParam(':nom',$nom,PDO::PARAM_STR);
	$requete->bindParam(':prenom',$prenom,PDO::PARAM_STR);
	$requete->bindParam(':tel',$tel,PDO::PARAM_STR);
	$requete->bindParam(':mail',$mail,PDO::PARAM_STR);
	$requete->bindParam(':adresse',$adresse,PDO::PARAM_STR);
	$requete ->execute();


	$rid = "SELECT id FROM projet.personne WHERE mail = :mail ";
	$requeteID = $BDD ->prepare($rid);
	$requeteID->bindParam(':mail',$mail,PDO::PARAM_STR);
	$requeteID ->execute();
    $resultat = $requeteID->fetchAll(PDO::FETCH_ASSOC);


    $id = $resultat[0]['id'];


	$texteRequeteUtil = "INSERT INTO projet.utilisateur VALUES
				(:login,:mdp,'$id')";
	$requeteUtil = $BDD ->prepare($texteRequeteUtil);
	$requeteUtil->bindParam(':login',$login,PDO::PARAM_STR);
	$requeteUtil->bindParam(':mdp',$mdp,PDO::PARAM_STR);
	$requeteUtil ->execute();


	$texteBenevole = "INSERT INTO projet.benevole VALUES ('$id')";
	$requeteBenevole = $BDD -> prepare($texteBenevole);
	$requeteBenevole -> execute();


	$textePermis = "INSERT INTO projet.permis_de_conduire VALUES (:numero, DATE '$datePermis', :prefecture, '$id')";
	$requetePermis = $BDD -> prepare($textePermis);
	$requetePermis->bindParam(':numero',$numero,PDO::PARAM_STR);
	$requetePermis->bindParam(':prefecture',$prefecture,PDO::PARAM_STR);
	$requetePermis ->execute();


	header("Location: telechargement.php");
	exit();
?>
