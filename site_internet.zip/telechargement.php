<!DOCTYPE html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="forme.css">

<html>
<head>
	<title> Bol d'air 2020 </title>
</head>	

<body>

	<h1 id="corps">
			<span>
				<img src="Images/logo.png" alt="mcu" id="logo">
				<span class="titre">  Téléchargement </span>
				<img src="Images/logo.png" alt="mcu" id="logo">
			</span>
	</h1>
	
	<img src="Images/spons1.png" alt="mcu" id="logos">

	<div id="tete">
		<br>
	</div>

	<?php include 'navbar.php' ?>

	<h2  class="border border-dark">
		<br> <br> 
			<p class="t1"> Cliquez ci-dessous pour télécharger l'application </p>
			<button class="btn btn-outline-success" type="submit" > <a href="Images/bouton.png" download="Application">Bol d'air</a></button>
   		<br> <br> <br>
	</h2>

	<br>  

	<img src="Images/spons2.png" alt="mcu" id="logos">
	<img src="Images/spons3.png" alt="mcu" id="logos">
	<img src="Images/spons4.png" alt="mcu" id="logos">

	</body>