<?php
	session_start();
	$BDD = new PDO('pgsql:host=localhost;port=5432;dbname=postgres','admin','adminadmin');

	$nom = $_POST["nom"];
	$prenom = $_POST["prenom"];
	$tel = $_POST["tel"];
	$mail = $_POST["mail"];
	$adresse = $_POST["adresse"];
	$date = $_POST["naissance"];
	$login = $_POST["login"];
	$mdp = $_POST["mdp"];

	$nom2 = $_POST["nom2"];
	$prenom2 = $_POST["prenom2"];
	$tel2 = $_POST["tel2"];
	$mail2 = $_POST["mail2"];
	$adresse2 = $_POST["adresse2"];
	$date2 = $_POST["naissance2"];
	$login2 = $_POST["login2"];
	$mdp2 = $_POST["mdp2"];

	$categorie = $_POST["categorie"];
	$repas = $_POST["repas"];
	$bol = $_POST["bol"];


	if(strlen($tel) != 10){
		header("Location: erreurTel.php");
		exit();
	}

	if(strlen($mdp) < 6){

		header("Location: erreurMdp.php");
		exit();
	}


	if(strlen($login) < 6){

		header("Location: erreurLogin.php");
		exit();
	}

	if(strlen($tel2) != 10){
		header("Location: erreurTel.php");
		exit();
	}

	if(strlen($mdp2) < 6){

		header("Location: erreurMdp.php");
		exit();
	}


	if(strlen($login2) < 6){

		header("Location: erreurLogin.php");
		exit();
	}







	$texteRequete = "INSERT INTO projet.personne(nom,prenom,datenaissance,tel,mail,adresse) VALUES (:nom,:prenom,DATE '$date',:tel,:mail,:adresse)";
	$requete = $BDD ->prepare($texteRequete);
	$requete->bindParam(':nom',$nom,PDO::PARAM_STR);
	$requete->bindParam(':prenom',$prenom,PDO::PARAM_STR);
	$requete->bindParam(':tel',$tel,PDO::PARAM_STR);
	$requete->bindParam(':mail',$mail,PDO::PARAM_STR);
	$requete->bindParam(':adresse',$adresse,PDO::PARAM_STR);
	$requete ->execute();


	$rid = "SELECT id FROM projet.personne WHERE mail = :mail ";
	$requeteID = $BDD ->prepare($rid);
	$requeteID->bindParam(':mail',$mail,PDO::PARAM_STR);
	$requeteID ->execute();
    $resultat = $requeteID->fetchAll(PDO::FETCH_ASSOC);


    $id = $resultat[0]['id'];


	$texteRequeteUtil = "INSERT INTO projet.utilisateur VALUES
				(:login,:mdp,'$id')";
	$requeteUtil = $BDD ->prepare($texteRequeteUtil);
	$requeteUtil->bindParam(':login',$login,PDO::PARAM_STR);
	$requeteUtil->bindParam(':mdp',$mdp,PDO::PARAM_STR);
	$requeteUtil ->execute();

	$texteParticipant1 = "INSERT INTO projet.participant VALUES ('$id',FALSE,FALSE,1,NULL)";
    $requeteParticipant1 = $BDD->prepare($texteParticipant1);
    $requeteParticipant1->execute();



	$texteRequete2 = "INSERT INTO projet.personne(nom,prenom,datenaissance,tel,mail,adresse) VALUES
				(:nom,:prenom,DATE '$date2',:tel,:mail,:adresse)";
	$requete2 = $BDD ->prepare($texteRequete2);
	$requete2->bindParam(':nom',$nom2,PDO::PARAM_STR);
	$requete2->bindParam(':prenom',$prenom2,PDO::PARAM_STR);
	$requete2->bindParam(':tel',$tel2,PDO::PARAM_STR);
	$requete2->bindParam(':mail',$mail2,PDO::PARAM_STR);
	$requete2->bindParam(':adresse',$adresse2,PDO::PARAM_STR);
	$requete2 ->execute();

	$rid2 = "SELECT id FROM projet.personne WHERE mail = :mail2 ";
	$requeteID2 = $BDD ->prepare($rid2);
	$requeteID2->bindParam(':mail2',$mail2,PDO::PARAM_STR);
	$requeteID2 ->execute();
    $resultat2 = $requeteID2->fetchAll(PDO::FETCH_ASSOC);

    $id2 = $resultat2[0]['id'];

    $texteRequeteUtil2 = "INSERT INTO projet.utilisateur VALUES
				(:login2,:mdp2,'$id2')";
	$requeteUtil2 = $BDD ->prepare($texteRequeteUtil2);
	$requeteUtil2->bindParam(':login2',$login2,PDO::PARAM_STR);
	$requeteUtil2->bindParam(':mdp2',$mdp2,PDO::PARAM_STR);
	$requeteUtil2 ->execute();








     $texteParticipant2 = "INSERT INTO projet.participant VALUES ('$id2',FALSE,FALSE,1,NULL)";
    $requeteParticipant2 = $BDD->prepare($texteParticipant2);
    $requeteParticipant2->execute();


		$texteEquipe = "INSERT INTO projet.equipe(paiement,nbr_repas,categorie,id_parcours,id_capitaine,id_equipier) VALUES (FALSE,'$repas',:categorie,'$bol','$id','$id2')";
		$requeteEquipe = $BDD ->prepare($texteEquipe);
		$requeteEquipe->bindParam(':categorie',$categorie,PDO::PARAM_STR);
		$requeteEquipe ->execute();

		$ridEquipe = "SELECT MAX(id) as id FROM projet.equipe ";
		$requeteIDEquipe = $BDD ->prepare($ridEquipe);
		$requeteIDEquipe ->execute();
		$resultat2 = $requeteIDEquipe->fetchAll(PDO::FETCH_ASSOC);

			$idEquipe = $resultat2[0]['id'];


			$texteEquipe = "UPDATE projet.participant SET id_Equipe = '$idEquipe' WHERE id = '$id' OR id = '$id2' ";
			$requeteEquipe = $BDD ->prepare($texteEquipe);
			$requeteEquipe->bindParam(':categorie',$categorie,PDO::PARAM_STR);
			$requeteEquipe ->execute();



	header("Location: telechargement.php");
	exit();
?>
