<!DOCTYPE html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link rel="stylesheet" href="forme.css">
<html>
<head>
	<title> Bol d'air 2020 </title>
</head>	

<body>


	<h1 id="corps">
			<span>
				<img src="Images/logo.png" alt="mcu" id="logo">
				<span class="titre">  Texte </span>
				<img src="Images/logo.png" alt="mcu" id="logo">
			</span>
	</h1>

	
	<img src="Images/spons1.png" alt="mcu" id="logos">

	<div id="tete">
		<br>
		
	</div>

		<nav class="navbar navbar-expand-lg  navbar-hover" id="nav">
	<div class="container-fluid">
		 
		<a class="navbar-brand" href="#"> <p class="t1"> Bol d'air </p> </a>
		<div class="collapse navbar-collapse" id="navbarContenu">
			<ul class="nav navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link" href="accueil.php"> <strong> <p class="t1">Accueil </p> </strong> </a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="participant.php"> <strong> <p class="t1">Inscription participant </p> </strong> </a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="benevole.php"> <strong> <p class="t1">Inscription bénévole </p></strong> </a>
				</li>

				<li class="nav-item active">
					<a class="nav-link" href="reglement.php"> <strong> <p class="t1">Règlement </p></strong> </a>
				</li>
			</ul>
			 <ul class="navbar-nav ml-auto">
           <li class="nav-item">
               <button class="ml-margin-right" type="submit" ><img src="Images/bouton.png" alt="mcu"
		></button>
          </li>
     </ul>
				
			

		</div>


		
	</div>
	</nav>

	<h2  class="border border-dark">
			<p class="text-danger"> Wesh </p>
	</h2>


	<br>  

	<img src="Images/spons2.png" alt="mcu" id="logos">
	<img src="Images/spons3.png" alt="mcu" id="logos">
	<img src="Images/spons4.png" alt="mcu" id="logos">

	</body>