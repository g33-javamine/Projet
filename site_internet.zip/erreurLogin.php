<!DOCTYPE html>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<html>

<style>
	body{
		background-color: #0C3563;
	}

	#bouton {
		display:block;
		position:relative;
		margin-left:auto;
		margin-right:auto;
	}
</style>

<head>
	<title> REESSAYER </title>
	
</head>

<body> 
	<br> <br> <br>

	<header> <div style="text-align:center"> <strong> <font size="+4"> <p class="text-danger"> Le login doit comporter au minimum 6 caractères, veuillez réessayer </p> </font> </strong> </div> </header>

	<button type="submit" id="bouton"> <strong> <a href="accueil.php"> Retour à l'accueil </a></strong> </button> 
</body>
</html>