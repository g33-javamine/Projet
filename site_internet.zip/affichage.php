<!DOCTYPE html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script>
	function supprimer_eleve(valeur){
		$("#"+valeur).hide();
}
</script>

<html>

<?php
	session_start();
	$BDD = new PDO('pgsql:host=localhost;port=5432;dbname=postgres','admin','adminadmin');
	$reponse = "SELECT nom, prenom FROM projet.personne";
	$requete = $BDD ->prepare($reponse);
	$requete->execute();
	$tabRes = $requete->fetchAll(PDO::FETCH_ASSOC);
?>

	<table class="table table-striped table-dark table-hover table-bordered"> 
		<thead>
			<th scope="col">  Nom </th>
			<th scope="col">  Prénom </th>
		</thead>

		<tbody>
			<?php foreach($tabRes as $uneLigne){?>
           		<?php echo '<tr id="'.$uneLigne['nom'].'">' ?>
                    <td>	<?php echo $uneLigne['nom'];?>		</td>
                    <td>	<?php echo $uneLigne['prenom'];?>	</td>
            <?php}?>
        </tbody>
    </table>
</html>