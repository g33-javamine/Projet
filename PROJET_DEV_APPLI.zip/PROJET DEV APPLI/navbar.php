<nav class="navbar navbar-expand-lg  navbar-hover" id="nav">
	<div class="container-fluid">
		 
		<a class="navbar-brand" href="#"> <p class="t1"> Bol d'air </p> </a>
		<div class="collapse navbar-collapse" id="navbarContenu">
			<ul class="nav navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link" href="accueil.php"> <strong> <p class="t1">Accueil </p> </strong> </a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="participant.php"> <strong> <p class="t1">Inscription participant </p> </strong> </a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="benevole.php"> <strong> <p class="t1">Inscription bénévole </p></strong> </a>
				</li>

				<li class="nav-item active">
					<a class="nav-link" href="reglement.php"> <strong> <p class="t1">Règlement </p></strong> </a>
				</li>
			</ul>
			 <ul class="navbar-nav ml-auto">
           <li class="nav-item">
               <button class="ml-margin-right" type="submit" ><img src="Images/bouton.png" alt="mcu"
		></button>
          </li>
     </ul>
				
			

		</div>


		
	</div>
	</nav>