<!DOCTYPE html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<html>
<head>
	<title> Bol d'air 2020 </title>
</head>	
<style>
	body 
	{
		background-color : #0C3563 ;
	}

	.navbar{
		background-color: #9FC8F4;

	}

	.t1 {
		color: #104E17;
	}
	.t2 {
		color: #104E17;
	}

	.t3 {
		color: #104E17;
	}

	.t4 {
		color: #104E17;
	}

	.t5 {
		color: #104E17;
	}
	.t6 {
		color: #104E17;
	}
	.t7 {
		color: #104E17;
	}

	.titre {
		color:#104E17;
	}

	#nav {


    	margin-left: auto;
    	margin-right : auto;


    	width : 50%;
    	
	}

	#bouton {
		text-align : margin-right;
	}

	#logos {
		display : block;
		position : relative;
		margin-left : auto;
		margin-right : auto;
	}

	#corps{
		color : #FFFFD5;
	}

	h1 {
    background-color:#9FC8F4; 
    margin-top: 100px; 
    text-align : center; 
    margin-left: 20%;
    margin-right: 20%;
    border-top: 20%;
}

	h2 {
    background-color:#FFFFD5; 
    margin-top: 100px; 
    text-align : center; 
    margin-left: 20%;
    margin-right: 20%;
    border-top: 20%;
}





</style>

<body>


	<h1 id="corps">
			<span>

				<img src="Images/logo.png" alt="mcu" id="logo">
				<span class="titre">  Accueil </span>
				<img src="Images/logo.png" alt="mcu" id="logo">
			</span>
	</h1>

	
	<img src="Images/spons1.png" alt="mcu" id="logos">

	<div id="tete">
		<br>
		<br>
		<br>
	</div>

	
	<?php include 'navbar.php' ?>
	
	<h2  class="border border-dark">
			<p class="t1">
			<br>
		BOL D'AIR ANNULÉ EN RAISON DE LA CRISE DU COVID 19
		<br>
		<br>
		Bienvenue sur le site du Bol d'Air !
	</p>

	
		
	

	<p class="t7">
		Sur ce site vous pourrez vous <a href="[LIEN A METTRE].php">inscrire</a> pour les différentes courses, ou bien en tant que bénévoles. 
		<br> <br>

		RAPPEL : Il est nécessaire d'avoir pris conscience du <a href="[LIEN A METTRE].php">règlement</a> de l'évènement avant de s'inscrire. </p>
		<br><br>
	</h2>


	<br> <br> 

	<img src="Images/spons2.png" alt="mcu" id="logos">
	<img src="Images/spons3.png" alt="mcu" id="logos">
	<img src="Images/spons4.png" alt="mcu" id="logos">

	</body>