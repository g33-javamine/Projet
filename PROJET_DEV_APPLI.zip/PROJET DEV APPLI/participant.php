<!DOCTYPE html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<html>
<head>
	<title> Inscription participant </title>
</head>	
<style>
	body 
	{
		background-color : #0C3563 ;
	}

	.navbar{
		background-color: #9FC8F4;

	}

	.t1 {
		color: #104E17;
	}
	

	.titre {
		color:#104E17;
	}

	#nav {


    	margin-left: auto;
    	margin-right : auto;


    	width : 50%;
    	
	}

	#bouton {
		text-align : margin-right;
	}

	#logos {
		display : block;
		position : relative;
		margin-left : auto;
		margin-right : auto;
	}

	#corps{
		color : #FFFFD5;
	}

	h1 {
    background-color:#9FC8F4; 
    margin-top: 100px; 
    text-align : center; 
    margin-left: 20%;
    margin-right: 20%;
    border-top: 20%;
}

	h2 {
    background-color:#FFFFD5; 
    margin-top: 100px; 
    text-align : center; 
    margin-left: 20%;
    margin-right: 20%;
    border-top: 20%;
}

	#form{
		margin-left : 30%;
		margin-right: 30%;
		margin-top : 5%;
		margin-bottom: 5%;
		color : #104E17;
	}
	

	#separation{
		background-color : #104E17 ;
		height : 2px;
		margin-left : 5%;
		margin-right : 5%;
	}





</style>

<body>


	<h1 id="corps">
			<span>

				<img src="Images/logo.png" alt="mcu" id="logo">
				<span class="titre"> Inscription </span>
				<img src="Images/logo.png" alt="mcu" id="logo">
			</span>
	</h1>

	
	<img src="Images/spons1.png" alt="mcu" id="logos">

	<div id="tete">
		<br>
		
	</div>

		<nav class="navbar navbar-expand-lg  navbar-hover" id="nav">
	<div class="container-fluid">
		 
		<a class="navbar-brand" href="#"> <p class="t1"> Bol d'air </p> </a>
		<div class="collapse navbar-collapse" id="navbarContenu">
			<ul class="nav navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link" href="accueil.php"> <strong> <p class="t1">Accueil </p> </strong> </a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="participant.php"> <strong> <p class="t1">Inscription participant </p> </strong> </a>
				</li>
				<li class="nav-item active">
					<a class="nav-link" href="benevole.php"> <strong> <p class="t1">Inscription bénévole </p></strong> </a>
				</li>

				<li class="nav-item active">
					<a class="nav-link" href="reglement.php"> <strong> <p class="t1">Règlement </p></strong> </a>
				</li>
			</ul>
			 <ul class="navbar-nav ml-auto">
           <li class="nav-item">
               <button class="ml-margin-right" type="submit" ><img src="Images/bouton.png" alt="mcu"
		></button>
          </li>
     </ul>
				
			

		</div>


		
	</div>
	</nav>

	<h2 class="border border-dark">
		<div id="form">
			

			<form id="InscriptionP" action="ConfirmationP.php" method="get">
		<font size="+4">BOL D'AIR </font>
		<br> <br>
		<div class="form-group">
    		<label for="Bol">Choix du Bol</label>
    			<select class="form-control" id="Bol">
      				<option>Bol d'Air</option>
      				<option>Mini Bol d'Air</option>
    			</select>
  		</div>

  		<br>

  		<div class="form-group">
    		<label for="Categorie">Catégorie</label>
    			<select class="form-control" id="Categorie">
      				<option>Hommes</option>
      				<option>Femmes</option>
      				<option>Mixte</option>
      				<option>V.A.E</option>
    			</select>
  		</div>
  		
  	</div>
  		

  		<div id="separation">
  				
  		</div>

  		<div id="form">
  			<font size="+4">CAPITAINE </font>

  		<br>
  		<br>




		<div class="form-group">
			<label id="Nom" for="inputNom">  Nom   </label>
			<input type="text" id="inputNom" name="nom" class="form-control" placeholder="Entrez nom">
		</div>

		<br>

		<div class="form-group">

			<label id="Prenom" for="inputPrenom">  Prénom  </label>
			<input type="text" id="inputPrenom" name="prenom" class="form-control" placeholder="Entrez prenom ">
		</div>

		<br>

		<div class="form-group">
			<label id="Naissance" for="inputNaissance"> Date de naissance  </label>
			<input type="text" id="inputNaissance" name="Naissance" class="form-control" placeholder="Entrez date de naissance">
		</div>

		<br>

		<div class="form-group">
			<label id="Tel" for="inputTel"> N° de téléphone </label>
			<input type="text" id="inputTel" name="Tel" class="form-control" placeholder="Entrez n° de téléphone">
		</div>

		<br>

		<div class="form-group">
			<label id="Adresse" for="inputAdresse"> Adresse </label>
			<input type="text" id="inputAdresse" name="Adresse" class="form-control" placeholder="Entrez adresse">
		</div>

		<br>

		<div class="form-group">
			<label id="Club" for="inputClasse"> Club  </label>
			<input type="text" id="inputClub" name="Club" class="form-control" placeholder="Entrez club">
		</div>

		<br>


		<div class="form-group">
			<label id="Matieres" for="inputMail">  Adresse mail  </label>
			<input type="mail" id="inputMail" name="Mail" class="form-control" placeholder="Entrez adresse mail">
		</div>
	</div>


  		<div id="separation">
  				
  		</div>

  		<div id="form">
  			<font size="+4">EQUIPIER </font>
		<br>
		<br>

		<div class="form-group">
			<label id="Nom" for="inputNom">  Nom   </label>
			<input type="text" id="inputNom" name="nom" class="form-control" placeholder="Entrez nom">
		</div>

		<br>

		<div class="form-group">

			<label id="Prenom" for="inputPrenom">  Prénom  </label>
			<input type="text" id="inputPrenom" name="prenom" class="form-control" placeholder="Entrez prenom ">
		</div>

		<br>

		<div class="form-group">
			<label id="Naissance" for="inputNaissance"> Date de naissance  </label>
			<input type="text" id="inputNaissance" name="Naissance" class="form-control" placeholder="Entrez date de naissance">
		</div>

		<br>

		<div class="form-group">
			<label id="Tel" for="inputTel"> N° de téléphone </label>
			<input type="text" id="inputTel" name="Tel" class="form-control" placeholder="Entrez n° de téléphone">
		</div>

		<br>

		<div class="form-group">
			<label id="Adresse" for="inputAdresse"> Adresse </label>
			<input type="text" id="inputAdresse" name="Adresse" class="form-control" placeholder="Entrez adresse">
		</div>

		<br>

		<div class="form-group">
			<label id="Club" for="inputClasse"> Club  </label>
			<input type="text" id="inputClub" name="Club" class="form-control" placeholder="Entrez club">
		</div>

		<br>


		<div class="form-group">
			<label id="Mail" for="inputMail">  Adresse mail  </label>
			<input type="text" id="inputMail" name="Mail" class="form-control" placeholder="Entrez adresse mail">
		</div>
	
		</div>

		<div id="separation">
  				
  		</div>

  		<div id="form">

  			<font size="+4">RESTAURATION </font>
		<br>
		<br>

			<div class="form-group">
    		<label for="Repas">Nombre de repas accompagnateurs</label>
    			<select class="form-control" id="Repas">
      				<option>1</option>
      				<option>2</option>
      				<option>3</option>
      				<option>4</option>
      				<option>5</option>
      				<option>6</option>
      				<option>7</option>
      				<option>8</option>
      				<option>9</option>
      				<option>10</option>

    			</select>
  		</div>


		

		<br>

		<button id="bouton" type="submit" class=" btn btn-outline-success">   Valider   </button>
	</div>
		
	</form>

	

	<br><br>
		<div id="form"> 
		<button type="submit" id="bouton" class=" btn btn-outline-success"> <strong> <a href="accueil.php"> Retour à l'accueil </a></strong> </button> 
		</div>
	</h2>


	<br>  

	<img src="Images/spons2.png" alt="mcu" id="logos">
	<img src="Images/spons3.png" alt="mcu" id="logos">
	<img src="Images/spons4.png" alt="mcu" id="logos">

	</body>