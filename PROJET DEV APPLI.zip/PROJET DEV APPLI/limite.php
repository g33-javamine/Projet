<!DOCTYPE html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<html>
<head>
	<title> Bol d'air 2020 </title>
</head>	
<style>
	body 
	{
		background-color : #0C3563 ;
	}

	#bouton {
		display:block;
		position:relative;
		margin-left:auto;
		margin-right:auto;
	}

	.t{
		color : #9FC8F4;
	}

	#centrer{
		margin-left: auto;
		 margin-right: auto;
  width: 70%;
	}

</style>

<body>

</body>

<br> <br> <br> <br> <br> <br>

<form id="centrer">
<div style="text-align:center"> <strong> <font size="+4"> <p class="t"> Limite d'inscription en tant que participant atteinte. Nous vous remercions tout de même. <br> N'hésitez à revenir l'année prochaine ! </p> </font> </strong> </div> 

<button type="submit" id="bouton" class=" btn btn-outline-success"> <strong> <a href="accueil.php"> Retour à l'accueil </a></strong> </button> 
</form>

</html> 